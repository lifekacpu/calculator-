import tkinter as tk
from tkinter import font

class Calculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Calculator")
        self.root.geometry("400x600")
        self.root.resizable(False, False)
        
        # Initialize variables
        self.current_input = ""
        self.result = 0
        self.operation = None
        self.reset_next_input = False
        
        # Configure styles
        self.configure_styles()
        
        # Create GUI
        self.create_widgets()
        
    def configure_styles(self):
        # Define fonts
        self.display_font = font.Font(family="Arial", size=24, weight="bold")
        self.button_font = font.Font(family="Arial", size=16, weight="bold")
        
        # Define colors
        self.display_bg = "#2C3E50"
        self.display_fg = "#00A9D3"
        self.number_bg = "#34495E"
        self.number_fg = "#57B333"
        self.operation_bg = "#2980B9"
        self.operation_fg = "#2D5964"
        self.special_bg = "#E74C3C"
        self.special_fg = "#274B53"
        
    def create_widgets(self):
        # Create display frame
        display_frame = tk.Frame(self.root, bg=self.display_bg, height=100)
        display_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Create display label
        self.display_var = tk.StringVar()
        self.display_var.set("0")
        self.display = tk.Label(
            display_frame,
            textvariable=self.display_var,
            font=self.display_font,
            bg=self.display_bg,
            fg=self.display_fg,
            anchor="e",
            padx=20
        )
        self.display.pack(fill=tk.BOTH, expand=True)
        
        # Create buttons frame
        buttons_frame = tk.Frame(self.root)
        buttons_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Button layout
        button_layout = [
            ['C', '±', '%', '/'],
            ['7', '8', '9', '*'],
            ['4', '5', '6', '-'],
            ['1', '2', '3', '+'],
            ['0', '.', '=']
        ]
        
        # Create buttons
        for i, row in enumerate(button_layout):
            buttons_frame.grid_rowconfigure(i, weight=1)
            for j, text in enumerate(row):
                buttons_frame.grid_columnconfigure(j, weight=1)
                
                if text == '=':
                    # Make equals button span 2 columns
                    btn = self.create_button(buttons_frame, text, 2, 1)
                    btn.grid(row=i, column=j, columnspan=2, sticky="nsew", padx=2, pady=2)
                elif text == '0':
                    # Make zero button span 2 columns
                    btn = self.create_button(buttons_frame, text, 2, 1)
                    btn.grid(row=i, column=j, columnspan=2, sticky="nsew", padx=2, pady=2)
                else:
                    btn = self.create_button(buttons_frame, text, 1, 1)
                    btn.grid(row=i, column=j, sticky="nsew", padx=2, pady=2)
    
    def create_button(self, parent, text, width, height):
        # Determine button style based on text
        if text in ['C', '±', '%']:
            bg = self.special_bg
            fg = self.special_fg
        elif text in ['+', '-', '*', '/', '=']:
            bg = self.operation_bg
            fg = self.operation_fg
        else:
            bg = self.number_bg
            fg = self.number_fg
            
        btn = tk.Button(
            parent,
            text=text,
            font=self.button_font,
            bg=bg,
            fg=fg,
            borderwidth=0,
            relief="flat",
            command=lambda: self.button_click(text)
        )
        
        # Add hover effects
        btn.bind("<Enter>", lambda e: btn.config(bg=self.lighten_color(bg)))
        btn.bind("<Leave>", lambda e: btn.config(bg=bg))
        
        return btn
    
    def lighten_color(self, color):
        # Convert hex to RGB
        r = int(color[1:3], 16)
        g = int(color[3:5], 16)
        b = int(color[5:7], 16)
        
        # Lighten the color
        r = min(255, r + 30)
        g = min(255, g + 30)
        b = min(255, b + 30)
        
        return f"#{r:02x}{g:02x}{b:02x}"
    
    def button_click(self, text):
        if text in '0123456789':
            self.handle_number(text)
        elif text == '.':
            self.handle_decimal()
        elif text in ['+', '-', '*', '/']:
            self.handle_operation(text)
        elif text == '=':
            self.calculate_result()
        elif text == 'C':
            self.clear_all()
        elif text == '±':
            self.toggle_sign()
        elif text == '%':
            self.handle_percentage()
    
    def handle_number(self, number):
        if self.reset_next_input:
            self.current_input = ""
            self.reset_next_input = False
        
        if self.current_input == "0":
            self.current_input = number
        else:
            self.current_input += number
        
        self.update_display()
    
    def handle_decimal(self):
        if self.reset_next_input:
            self.current_input = "0"
            self.reset_next_input = False
        
        if '.' not in self.current_input:
            if not self.current_input:
                self.current_input = "0"
            self.current_input += '.'
            self.update_display()
    
    def handle_operation(self, op):
        if self.current_input:
            if self.operation:
                self.calculate_result()
            self.result = float(self.current_input)
            self.operation = op
            self.reset_next_input = True
    
    def calculate_result(self):
        if self.operation and self.current_input:
            try:
                current = float(self.current_input)
                if self.operation == '+':
                    self.result += current
                elif self.operation == '-':
                    self.result -= current
                elif self.operation == '*':
                    self.result *= current
                elif self.operation == '/':
                    if current == 0:
                        self.display_var.set("Error")
                        self.clear_all()
                        return
                    self.result /= current
                
                # Format result to avoid floating point issues
                if self.result.is_integer():
                    self.result = int(self.result)
                
                self.display_var.set(str(self.result))
                self.current_input = str(self.result)
                self.operation = None
                self.reset_next_input = True
                
            except Exception as e:
                self.display_var.set("Error")
                self.clear_all()
    
    def clear_all(self):
        self.current_input = ""
        self.result = 0
        self.operation = None
        self.reset_next_input = False
        self.display_var.set("0")
    
    def toggle_sign(self):
        if self.current_input and self.current_input != "0":
            if self.current_input[0] == '-':
                self.current_input = self.current_input[1:]
            else:
                self.current_input = '-' + self.current_input
            self.update_display()
    
    def handle_percentage(self):
        if self.current_input:
            try:
                value = float(self.current_input) / 100
                if self.operation in ['+', '-'] and self.result:
                    value = self.result * value
                
                if value.is_integer():
                    self.current_input = str(int(value))
                else:
                    self.current_input = str(value)
                
                self.update_display()
            except:
                self.display_var.set("Error")
                self.clear_all()
    
    def update_display(self):
        # Limit display length
        if len(self.current_input) > 12:
            self.display_var.set(self.current_input[:12] + "...")
        else:
            self.display_var.set(self.current_input)

def main():
    root = tk.Tk()
    calculator = Calculator(root)
    root.mainloop()

if __name__ == "__main__":
    main()